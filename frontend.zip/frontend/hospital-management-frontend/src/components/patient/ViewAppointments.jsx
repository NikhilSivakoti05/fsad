import React from 'react';
import { Box, Typography } from '@mui/material';

const ViewAppointments = () => {
  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h5">View Appointments</Typography>
      {/* Add your appointments table here */}
    </Box>
  );
};

export default ViewAppointments;
