import React from 'react';
import { Box, Typography } from '@mui/material';

const MedicalHistory = () => {
  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h5">Medical History</Typography>
      {/* Add your medical history details here */}
    </Box>
  );
};

export default MedicalHistory;
