package com.hospital.enums;

public enum Status {
	ACTIVE, INACTIVE
}
