import React from 'react'

export default function NotFound() {
  return (
    <div>This page not found</div>
  )
}
